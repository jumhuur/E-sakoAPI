from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse , FileResponse
from fastapi.staticfiles import StaticFiles
from Dahab import xisaab_Dahab
from Lacag import Lacag
from Fido import Fido
from Rikaas import Rikaas
from Geel import Geel
from Loa import Loa
from Adhi import Adhi
from Dalag import Dalag
from Errors import Errors
#app
app = FastAPI(
    title="E-sako API", 
    version="1.01",
    docs_url=None,
    redoc_url=None,
    openapi_url=None
    )


# app = FastAPI(
#     title="E-sako API", 
#     version="1.01",
#     )


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],      # dhamaan waa lo ogol_yahay
    allow_credentials=True,
    allow_methods=["GET"],        # GET
    allow_headers=["*"],        # headers
)



@app.exception_handler(404)
async def not_found(request: Request, exc):
    return JSONResponse(
        status_code=404,
        content=Errors(467,False)
    )


@app.get("/api/dahab/{nooc},{xadiga}")
async def xisaab(nooc:int,xadiga:float):
    if nooc and xadiga:
        return  xisaab_Dahab(nooc,xadiga)
    raise JSONResponse(
            status_code=467,
            content= Errors(467)
        )

@app.get("/api/lacag/{xadi}")
async def lacag(xadi:int):
    if xadi:
        return Lacag(xadi)
    else:
        raise JSONResponse(
            status_code=467,
            content= Errors(467)
        )



@app.get("/api/fido/{xadi}")
async def Fido_sako(xadi:int):
    if xadi:
        return Fido(xadi)
    else:
        return JSONResponse(
            status_code=467,
            content= Errors(467)
        )


@app.get("/api/rikaas/{xadi}")
async def Rikaas_xisaab(xadi:int):
    if xadi:
        return Rikaas(xadi)
    else:
        return JSONResponse(
            status_code=467,
            content= Errors(467)
        )

@app.get("/api/geel/{xadi}")
async def xisaab_geel(xadi:int):
    if xadi:
        return Geel(xadi)
    else:
        return JSONResponse(
            status_code=467,
            content= Errors(467)
        )

@app.get("/api/lo/{xadi}")
async def xisaab_lo(xadi):
    if xadi:
        return Loa(xadi)
    else:
        return JSONResponse(
            status_code=467,
            content= Errors(467)
        )



@app.get("/api/adhi/{xadi}")
async def xisaab_adhi(xadi):
    if xadi:
        return Adhi(xadi)
    else:
        return JSONResponse(
            status_code=467,
            content= Errors(467)
        )


@app.get("/api/dalag/{xadi}")
async def xisaab_dalag(xadi,nooc=1):
    if xadi:
        return Dalag(xadi,nooc)
    else:
        return JSONResponse(
            status_code=467,
            content= Errors(467)
        )


@app.get("/")
def Home():
    return FileResponse("static/index.html")

@app.get("/doc")
def Docs_page():
    return FileResponse("static/docs.html")

