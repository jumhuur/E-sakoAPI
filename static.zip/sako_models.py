from pydantic import BaseModel
class skawaat(BaseModel):
    item:str
    call_counts:int
    last_call:str


class calc_sakaat(BaseModel):
    pass
